
package com.forexintelligence.ai

import com.forexintelligence.ai.ui.AIAnalystScreen
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

private val Background = Color(0xFF080E19)
private val Panel = Color(0xFF111D2D)
private val Cyan = Color(0xFF61D5DF)
private val Muted = Color(0xFF91A2B8)
private val Amber = Color(0xFFF0BD69)

private const val API_URL =
    "http://127.0.0.1:8000/api/analyst/aggregate-news"

private val apiClient = OkHttpClient()

private val JSON_MEDIA_TYPE =
    "application/json; charset=utf-8".toMediaType()


data class NewsArticle(
    val title: String,
    val content: String
)

data class SupportingGroup(
    val label: String,
    val articles: List<String>
)

data class NewsAnalysisResult(
    val articleCount: Int,
    val validArticleCount: Int,
    val contextSummary: List<Pair<String, Int>>,
    val usdImpact: String,
    val goldImpact: String,
    val confidence: String,
    val conflictDetected: Boolean,
    val interpretation: String,
    val supportingGroups: List<SupportingGroup>,
    val educationalNotice: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ForexDashboard()
        }
    }
}

@Composable
fun ForexDashboard() {

    var selectedTab by remember {
        mutableStateOf("Overview")
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Background,
            surface = Panel,
            primary = Cyan
        )
    ) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(
                    containerColor = Panel
                ) {
                    listOf(
                        "Overview",
                        "Calendar",
                        "News",
                        "AI Analysis"
                    ).forEach { tab ->

                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = {
                                selectedTab = tab
                            },
                            icon = {},
                            label = {
                                Text(
                                    tab,
                                    fontSize = 10.sp
                                )
                            }
                        )
                    }
                }
            }
        ) { padding ->

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Background)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {

                Text(
                    "FOREX INTELLIGENCE AI",
                    color = Cyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(18.dp))

                when (selectedTab) {
                    "Overview" -> DashboardContent()

                    "Calendar" -> ModuleContent(
                        "Economic Calendar"
                    )

                    "News" -> NewsIntelligenceScreen()

                    "AI Analysis" -> AIAnalystScreen()
                }
            }
        }
    }
}

@Composable
fun OverviewContent() {

    Text(
        "Market Overview",
        color = Color.White,
        fontSize = 27.sp,
        fontWeight = FontWeight.Bold
    )

    Text(
        "Fundamental + Technical Intelligence",
        color = Muted,
        fontSize = 12.sp
    )

    Spacer(Modifier.height(22.dp))

    MarketCard(
        "INSTRUMENT",
        "XAU/USD",
        "Gold / US Dollar"
    )

    Spacer(Modifier.height(12.dp))

    MarketCard(
        "MARKET BIAS",
        "NEUTRAL",
        "Belum ada data live"
    )

    Spacer(Modifier.height(18.dp))

    Text(
        "AI MARKET OUTLOOK",
        color = Cyan,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp
    )

    Spacer(Modifier.height(10.dp))

    MarketCard(
        "FUNDAMENTAL",
        "Waiting for data",
        "NFP • CPI • PPI • FOMC"
    )

    Spacer(Modifier.height(12.dp))

    MarketCard(
        "TECHNICAL",
        "Waiting for data",
        "Trend • RSI • EMA • MACD"
    )
}

@Composable
fun MarketCard(
    title: String,
    value: String,
    description: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = Panel
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                title,
                color = Muted,
                fontSize = 10.sp
            )

            Spacer(Modifier.height(6.dp))

            Text(
                value,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                description,
                color = Muted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun ModuleContent(name: String) {
    Text(
        name,
        color = Color.White,
        fontSize = 25.sp,
        fontWeight = FontWeight.Bold
    )

    Spacer(Modifier.height(12.dp))

    Text(
        "Modul sedang dalam tahap pengembangan.",
        color = Muted
    )
}

// =====================================
// NEWS INTELLIGENCE SCREEN
// =====================================

@Composable
fun NewsIntelligenceScreen() {

    val scope = rememberCoroutineScope()

    val articles = remember {
        mutableStateListOf<NewsArticle>()
    }

    var title by remember {
        mutableStateOf("")
    }

    var content by remember {
        mutableStateOf("")
    }

    var loading by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf("")
    }

    var result by remember {
        mutableStateOf<NewsAnalysisResult?>(null)
    }

    Text(
        "News Intelligence",
        color = Color.White,
        fontSize = 25.sp,
        fontWeight = FontWeight.Bold
    )

    Spacer(Modifier.height(6.dp))

    Text(
        "Analisis gabungan konteks berita ekonomi",
        color = Muted,
        fontSize = 12.sp
    )

    Spacer(Modifier.height(20.dp))

    Text(
        "INPUT BERITA",
        color = Cyan,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
    )

    Spacer(Modifier.height(10.dp))

    OutlinedTextField(
        value = title,
        onValueChange = {
            title = it
        },
        modifier = Modifier.fillMaxWidth(),
        label = {
            Text("Judul berita")
        },
        singleLine = true
    )

    Spacer(Modifier.height(10.dp))

    OutlinedTextField(
        value = content,
        onValueChange = {
            content = it
        },
        modifier = Modifier.fillMaxWidth(),
        label = {
            Text("Isi berita")
        },
        minLines = 4
    )

    Spacer(Modifier.height(12.dp))

    Button(
        onClick = {

            if (title.isBlank() || content.isBlank()) {
                errorMessage = "Isi judul dan isi berita terlebih dahulu."
            } else {
                articles.add(
                    NewsArticle(
                        title = title.trim(),
                        content = content.trim()
                    )
                )

                title = ""
                content = ""
                errorMessage = ""
                result = null
            }
        },
        modifier = Modifier.fillMaxWidth(),
        enabled = !loading
    ) {
        Text("Tambah Berita")
    }

    Spacer(Modifier.height(18.dp))

    Text(
        "DAFTAR BERITA (${articles.size})",
        color = Cyan,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
    )

    Spacer(Modifier.height(8.dp))

    if (articles.isEmpty()) {
        Text(
            "Belum ada berita yang ditambahkan.",
            color = Muted,
            fontSize = 12.sp
        )
    }

    articles.forEachIndexed { index, article ->

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 5.dp),
            colors = CardDefaults.cardColors(
                containerColor = Panel
            )
        ) {
            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                Text(
                    article.title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(5.dp))

                Text(
                    article.content,
                    color = Muted,
                    fontSize = 12.sp
                )

                TextButton(
                    onClick = {
                        articles.removeAt(index)
                    }
                ) {
                    Text(
                        "Hapus",
                        color = Amber
                    )
                }
            }
        }
    }

    Spacer(Modifier.height(14.dp))

    Button(
        onClick = {

            val requestArticles = articles.toMutableList()

            val hasTitle = title.isNotBlank()
            val hasContent = content.isNotBlank()

            if (hasTitle != hasContent) {
                errorMessage =
                    "Lengkapi judul dan isi berita."
                return@Button
            }

            if (hasTitle && hasContent) {
                requestArticles.add(
                    NewsArticle(
                        title = title.trim(),
                        content = content.trim()
                    )
                )
            }

            if (requestArticles.isEmpty()) {
                errorMessage =
                    "Tambahkan minimal satu berita."
                return@Button
            }

            if (requestArticles.size > 50) {
                errorMessage =
                    "Maksimal 50 berita dalam satu analisis."
                return@Button
            }

            errorMessage = ""
            loading = true
            result = null

            scope.launch {
                try {
                    result = requestAggregateNews(
                        requestArticles
                    )
                } catch (error: Exception) {
                    errorMessage =
                        error.message
                            ?: "Gagal menghubungi backend."
                } finally {
                    loading = false
                }
            }
        },
        modifier = Modifier.fillMaxWidth(),
        enabled = !loading
    ) {
        Text("ANALISIS SEMUA BERITA")
    }

    if (loading) {
        Spacer(Modifier.height(16.dp))

        CircularProgressIndicator(
            color = Cyan
        )

        Text(
            "Sedang menganalisis berita...",
            color = Muted,
            fontSize = 12.sp
        )
    }

    if (errorMessage.isNotBlank()) {
        Spacer(Modifier.height(12.dp))

        Text(
            errorMessage,
            color = Color(0xFFFF7777),
            fontSize = 12.sp
        )
    }

    result?.let {
        Spacer(Modifier.height(24.dp))
        NewsAnalysisResultContent(it)
    }
}

// =====================================
// NEWS ANALYSIS RESULT
// =====================================

@Composable
fun NewsAnalysisResultContent(
    result: NewsAnalysisResult
) {

    Text(
        "HASIL ANALISIS",
        color = Cyan,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
    )

    Spacer(Modifier.height(12.dp))

    MarketCard(
        "JUMLAH BERITA",
        "${result.validArticleCount} / ${result.articleCount}",
        "Berita berhasil dianalisis"
    )

    Spacer(Modifier.height(10.dp))

    MarketCard(
        "KONTEKS USD",
        result.usdImpact,
        "Pengelompokan konteks berita"
    )

    Spacer(Modifier.height(10.dp))

    MarketCard(
        "KONTEKS EMAS",
        result.goldImpact,
        "Pengelompokan konteks berita"
    )

    Spacer(Modifier.height(10.dp))

    MarketCard(
        "CONFIDENCE",
        result.confidence,
        "Tingkat keyakinan sistem"
    )

    Spacer(Modifier.height(14.dp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Panel
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Text(
                "RINGKASAN KONTEKS",
                color = Cyan,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )

            Spacer(Modifier.height(10.dp))

            if (result.contextSummary.isEmpty()) {
                Text(
                    "Belum ada konteks yang terdeteksi.",
                    color = Muted
                )
            }

            result.contextSummary.forEach { item ->
                Text(
                    "${item.first}: ${item.second} berita",
                    color = Color.White,
                    fontSize = 13.sp
                )
            }
        }
    }

    Spacer(Modifier.height(12.dp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Panel
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Text(
                "INTERPRETASI AI",
                color = Cyan,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )

            Spacer(Modifier.height(8.dp))

            Text(
                result.interpretation,
                color = Color.White,
                fontSize = 13.sp
            )

            Spacer(Modifier.height(12.dp))

            Text(
                if (result.conflictDetected) {
                    "Terdapat konflik konteks antarberita."
                } else {
                    "Tidak terdeteksi konflik konteks."
                },
                color = if (result.conflictDetected) {
                    Amber
                } else {
                    Muted
                },
                fontSize = 12.sp
            )
        }
    }

    result.supportingGroups.forEach { group ->

        Spacer(Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Panel
            )
        ) {
            Column(
                modifier = Modifier.padding(14.dp)
            ) {
                Text(
                    group.label,
                    color = Cyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                Spacer(Modifier.height(8.dp))

                group.articles.forEach { articleTitle ->
                    Text(
                        "• $articleTitle",
                        color = Color.White,
                        fontSize = 12.sp
                    )

                    Spacer(Modifier.height(5.dp))
                }
            }
        }
    }

    Spacer(Modifier.height(12.dp))

    Text(
        result.educationalNotice,
        color = Muted,
        fontSize = 11.sp
    )
}

// =====================================
// API REQUEST
// =====================================

private suspend fun requestAggregateNews(
    articles: List<NewsArticle>
): NewsAnalysisResult = withContext(Dispatchers.IO) {

    val jsonArticles = JSONArray()

    articles.forEach { article ->
        jsonArticles.put(
            JSONObject()
                .put("title", article.title)
                .put("content", article.content)
        )
    }

    val jsonBody = JSONObject()
        .put("articles", jsonArticles)
        .toString()

    val requestBody = jsonBody.toRequestBody(
        JSON_MEDIA_TYPE
    )

    val request = Request.Builder()
        .url(API_URL)
        .post(requestBody)
        .build()

    apiClient.newCall(request).execute().use { response ->

        val responseText =
            response.body?.string().orEmpty()

        if (!response.isSuccessful) {
            throw IOException(
                "HTTP ${response.code}: $responseText"
            )
        }

        val json = JSONObject(responseText)

        if (
            json.optString("status") == "INVALID" ||
            json.optString("status") == "ERROR"
        ) {
            throw IOException(
                json.optString(
                    "error",
                    "Analisis gagal."
                )
            )
        }

        json.toNewsAnalysisResult()
    }
}

// =====================================
// JSON RESPONSE PARSER
// =====================================

private fun JSONObject.toNewsAnalysisResult(): NewsAnalysisResult {

    val contextObject =
        optJSONObject("context_summary") ?: JSONObject()

    val contextSummary = mutableListOf<Pair<String, Int>>()

    val keys = contextObject.keys()

    while (keys.hasNext()) {
        val key = keys.next()

        contextSummary.add(
            key to contextObject.optInt(key, 0)
        )
    }

    val supportingObject =
        optJSONObject("supporting_articles") ?: JSONObject()

    val groupDefinitions = listOf(
        "USD Bullish" to "usd_bullish",
        "USD Bearish" to "usd_bearish",
        "Context Dependent" to "context_dependent",
        "Mixed" to "mixed"
    )

    val supportingGroups = groupDefinitions.mapNotNull {
        (label, key) ->

        val array =
            supportingObject.optJSONArray(key) ?: JSONArray()

        val titles = mutableListOf<String>()

        for (index in 0 until array.length()) {
            titles.add(array.optString(index))
        }

        if (titles.isEmpty()) {
            null
        } else {
            SupportingGroup(
                label = label,
                articles = titles
            )
        }
    }

    return NewsAnalysisResult(
        articleCount = optInt("article_count", 0),
        validArticleCount = optInt("valid_article_count", 0),
        contextSummary = contextSummary,
        usdImpact = optString(
            "overall_usd_impact",
            "UNCERTAIN"
        ),
        goldImpact = optString(
            "overall_gold_impact",
            "UNCERTAIN"
        ),
        confidence = optString(
            "confidence",
            "LOW"
        ),
        conflictDetected = optBoolean(
            "conflict_detected",
            false
        ),
        interpretation = optString(
          