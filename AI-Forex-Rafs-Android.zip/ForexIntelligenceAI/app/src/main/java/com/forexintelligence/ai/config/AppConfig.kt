
package com.forexintelligence.ai.config

object AppConfig {

    // Backend utama aplikasi
    const val BASE_URL = 
          "http://127.0.0.1:8000"

    // Instrumen prioritas
    val SUPPORTED_SYMBOLS = listOf(
        "XAU/USD",
        "EUR/USD",
        "GBP/USD",
        "USD/JPY",
        "AUD/USD",
        "USD/CHF"
    )

    // Timeframe analisis
    val SUPPORTED_TIMEFRAMES = listOf(
        "M15",
        "H1",
        "H4",
        "D1"
    )

    // Pengaturan pembaruan
    const val CONNECTION_TIMEOUT = 15L
    const val READ_TIMEOUT = 20L

    // Versi aplikasi
    const val APP_VERSION = "0.1.0"

    // Status pengembangan
    const val IS_DEVELOPMENT = true
}
