
package com.forexintelligence.ai.data

import com.forexintelligence.ai.config.AppConfig
import com.forexintelligence.ai.model.ChatMessage
import com.forexintelligence.ai.model.MarketContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.OkHttpClient
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AIAnalystRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun ask(
        question: String,
        context: MarketContext,
        history: List<ChatMessage>
    ): Result<String> = withContext(Dispatchers.IO) {

        runCatching {

            require(question.isNotBlank()) {
                "Pertanyaan tidak boleh kosong."
            }

            require(question.length <= 4000) {
                "Pertanyaan terlalu panjang."
            }

            val historyJson = history.takeLast(10).map {
                JSONObject().apply {
                    put("role", it.role.name.lowercase())
                    put("content", it.content)
                }
            }

            val contextJson = JSONObject().apply {
                put("symbol", context.symbol)
                put("timeframe", context.timeframe)
                put("fundamental", context.fundamentalSummary)
                put("technical", context.technicalSummary)
                put("news", context.newsSummary)
                put("goldImpact", context.goldImpactSummary)
                put("lastUpdated", context.lastUpdated)
            }

            val payload = JSONObject().apply {
                put("question", question)
                put("context", contextJson)
                put("history", org.json.JSONArray(historyJson))
            }

            val body = payload.toString().toRequestBody(
                "application/json; charset=utf-8".toMediaType()
            )

            val request = Request.Builder()
                .url("${AppConfig.BASE_URL}/api/analyst/chat")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->

                if (!response.isSuccessful) {
                    throw Exception(
                        "Server error: ${response.code}"
                    )
                }

                val responseText = response.body?.string()
                    ?: throw Exception("Respons server kosong.")

                val json = JSONObject(responseText)

                json.optString("answer").takeIf {
                    it.isNotBlank()
                } ?: throw Exception(
                    "Jawaban AI tidak ditemukan."
                )
            }
        }
    }
}
