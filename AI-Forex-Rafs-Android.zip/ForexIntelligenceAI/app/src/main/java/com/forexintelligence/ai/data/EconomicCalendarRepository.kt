
package com.forexintelligence.ai.data

import com.forexintelligence.ai.model.EconomicEvent
import com.forexintelligence.ai.model.NewsImpact
import com.forexintelligence.ai.network.ApiClient
import org.json.JSONObject

object EconomicCalendarRepository {

    suspend fun getEvents(): Result<List<EconomicEvent>> {

        return try {

            val response = ApiClient.get(
                "/api/calendar?currency=USD"
            ).getOrThrow()

            val root = JSONObject(response)
            val eventsJson = root.getJSONArray("events")

            val events = mutableListOf<EconomicEvent>()

            for (i in 0 until eventsJson.length()) {

                val item = eventsJson.getJSONObject(i)

                val impact = when (
                    item.optString("impact").uppercase()
                ) {
                    "HIGH" -> NewsImpact.HIGH
                    "MEDIUM" -> NewsImpact.MEDIUM
                    "LOW" -> NewsImpact.LOW
                    else -> NewsImpact.UNKNOWN
                }

                events.add(
                    EconomicEvent(
                        id = item.optString("id"),
                        eventName = item.optString("event"),
                        currency = item.optString("currency", "USD"),
                        country = item.optString("country", "US"),
                        impact = impact,
                        scheduledTime = item.optLong("timestamp"),
                        actual = item.optionalString("actual"),
                        forecast = item.optionalString("forecast"),
                        previous = item.optionalString("previous"),
                        source = item.optString("source", "Unknown")
                    )
                )
            }

            Result.success(events)

        } catch (exception: Exception) {

            Result.failure(
                exception.message?.let {
                    Exception(it)
                } ?: Exception("Gagal mengambil kalender ekonomi.")
            )
        }
    }

    private fun JSONObject.optionalString(
        key: String
    ): String? {
        if (isNull(key)) return null

        return optString(key).takeIf {
            it.isNotBlank() && it != "null"
        }
    }
}
