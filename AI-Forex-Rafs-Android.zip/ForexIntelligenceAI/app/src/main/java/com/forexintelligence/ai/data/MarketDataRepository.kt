
package com.forexintelligence.ai.data

import com.forexintelligence.ai.model.Candle
import com.forexintelligence.ai.model.CandleValidator
import com.forexintelligence.ai.model.MarketData
import com.forexintelligence.ai.model.Timeframe

// Kontrak untuk sumber data harga.
// Nantinya bisa dihubungkan ke API penyedia data.
interface MarketDataSource {

    suspend fun fetchCandles(
        symbol: String,
        timeframe: Timeframe
    ): List<Candle>
}

// Status hasil pengambilan data.
sealed class MarketDataResult {

    data class Success(
        val marketData: MarketData
    ) : MarketDataResult()

    data class Error(
        val message: String
    ) : MarketDataResult()
}

class MarketDataRepository(
    private val dataSource: MarketDataSource
) {

    suspend fun getMarketData(
        symbol: String,
        timeframe: Timeframe
    ): MarketDataResult {

        if (symbol.isBlank()) {
            return MarketDataResult.Error(
                "Simbol instrumen tidak boleh kosong."
            )
        }

        return try {

            val candles = dataSource.fetchCandles(
                symbol = symbol,
                timeframe = timeframe
            )

            val validation = CandleValidator.validate(candles)

            if (!validation.isValid) {
                return MarketDataResult.Error(
                    validation.errors.joinToString("\n")
                )
            }

            val marketData = MarketData(
                symbol = symbol,
                timeframe = timeframe,
                candles = candles,
                source = "External API",
                lastUpdated = System.currentTimeMillis()
            )

            MarketDataResult.Success(marketData)

        } catch (exception: Exception) {

            MarketDataResult.Error(
                exception.message
                    ?: "Gagal mengambil data pasar."
            )
        }
    }
}
