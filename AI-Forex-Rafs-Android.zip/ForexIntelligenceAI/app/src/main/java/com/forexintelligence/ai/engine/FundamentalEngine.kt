
package com.forexintelligence.ai.engine

import com.forexintelligence.ai.model.EconomicRelease
import com.forexintelligence.ai.model.EconomicIndicator
import com.forexintelligence.ai.model.FundamentalImpact

import com.forexintelligence.ai.model.FundamentalAnalysis

object FundamentalEngine {

    fun analyze(
        release: EconomicRelease
    ): FundamentalAnalysis {

        val actual = release.actual
        val forecast = release.forecast

        if (actual == null || forecast == null) {
            return FundamentalAnalysis(
                indicator = release.indicator,
                impact = FundamentalImpact.UNKNOWN,
                explanation = "Data aktual atau forecast belum tersedia.",
                actualVsForecast = "Belum dapat dibandingkan",
                dataComplete = false
            )
        }

        val difference = actual - forecast

        val result = when (release.indicator) {

            EconomicIndicator.NFP,
            EconomicIndicator.GDP -> {
                when {
                    difference > 0 -> FundamentalImpact.USD_BULLISH
                    difference < 0 -> FundamentalImpact.USD_BEARISH
                    else -> FundamentalImpact.NEUTRAL
                }
            }

            EconomicIndicator.CPI,
            EconomicIndicator.CORE_CPI,
            EconomicIndicator.PPI,
            EconomicIndicator.PCE,
            EconomicIndicator.CORE_PCE -> {
                when {
                    difference > 0 -> FundamentalImpact.USD_BULLISH
                    difference < 0 -> FundamentalImpact.USD_BEARISH
                    else -> FundamentalImpact.NEUTRAL
                }
            }

            EconomicIndicator.UNEMPLOYMENT_RATE -> {
                when {
                    difference > 0 -> FundamentalImpact.USD_BEARISH
                    difference < 0 -> FundamentalImpact.USD_BULLISH
                    else -> FundamentalImpact.NEUTRAL
                }
            }

            else -> FundamentalImpact.UNKNOWN
        }

        val comparison = when {
            difference > 0 -> "Aktual lebih tinggi dari forecast"
            difference < 0 -> "Aktual lebih rendah dari forecast"
            else -> "Aktual sesuai forecast"
        }

        val explanation = when (result) {
            FundamentalImpact.USD_BULLISH ->
                "Data dapat mendukung USD, tetapi perlu diperiksa bersama komponen data dan ekspektasi kebijakan The Fed."

            FundamentalImpact.USD_BEARISH ->
                "Data dapat menekan USD, tetapi dampak akhirnya bergantung pada konteks ekonomi dan respons pasar."

            FundamentalImpact.NEUTRAL ->
                "Data sesuai perkiraan sehingga kejutan terhadap ekspektasi relatif terbatas."

            else ->
                "Arah dampak belum dapat ditentukan dari data ini saja."
        }

        return FundamentalAnalysis(
            indicator = release.indicator,
            impact = result,
            explanation = explanation,
            actualVsForecast = comparison,
            dataComplete = true
        )
    }
}
