
package com.forexintelligence.ai.engine

import com.forexintelligence.ai.model.FundamentalContext
import com.forexintelligence.ai.model.FundamentalImpact
import com.forexintelligence.ai.model.GoldDirection
import com.forexintelligence.ai.model.GoldImpactAnalysis

object GoldImpactAnalyzer {

    fun analyze(
        context: FundamentalContext
    ): GoldImpactAnalysis {

        var score = 0

        val supporting = mutableListOf<String>()
        val opposing = mutableListOf<String>()
        val limitations = mutableListOf<String>()

        when (context.overallImpact) {

            FundamentalImpact.USD_BULLISH -> {
                score -= 2
                supporting.add(
                    "Kondisi fundamental USD berpotensi menekan emas."
                )
            }

            FundamentalImpact.USD_BEARISH -> {
                score += 2
                supporting.add(
                    "Kondisi fundamental USD berpotensi mendukung emas."
                )
            }

            FundamentalImpact.MIXED -> {
                limitations.add(
                    "Indikator fundamental USD memberikan hasil campuran."
                )
            }

            FundamentalImpact.NEUTRAL -> {
                limitations.add(
                    "Belum ada kecenderungan fundamental yang kuat."
                )
            }

            FundamentalImpact.UNKNOWN -> {
                limitations.add(
                    "Data fundamental belum mencukupi."
                )
            }
        }

        if (context.bullishFactors.isNotEmpty() &&
            context.bearishFactors.isNotEmpty()
        ) {
            opposing.add(
                "Terdapat indikator ekonomi yang saling bertentangan."
            )
        }

        if (context.analyses.size < 3) {
            limitations.add(
                "Jumlah indikator yang tersedia masih terbatas."
            )
        }

        val direction = when {
            context.overallImpact == FundamentalImpact.UNKNOWN ->
                GoldDirection.UNCERTAIN

            context.overallImpact == FundamentalImpact.MIXED ->
                GoldDirection.MIXED

            score > 0 ->
                GoldDirection.POTENTIAL_UP

            score < 0 ->
                GoldDirection.POTENTIAL_DOWN

            else ->
                GoldDirection.UNCERTAIN
        }

        val explanation = when (direction) {
            GoldDirection.POTENTIAL_UP ->
                "Faktor fundamental yang tersedia berpotensi mendukung kenaikan emas. Konfirmasi diperlukan dari kondisi pasar."

            GoldDirection.POTENTIAL_DOWN ->
                "Faktor fundamental yang tersedia berpotensi menekan emas. Konfirmasi diperlukan dari kondisi pasar."

            GoldDirection.MIXED ->
                "Faktor fundamental belum searah. Reaksi emas dapat menjadi tidak konsisten."

            GoldDirection.UNCERTAIN ->
                "Belum cukup informasi untuk memperkirakan dampak terhadap emas."
        }

        return GoldImpactAnalysis(
            direction = direction,
            score = score,
            supportingFactors = supporting,
            opposingFactors = opposing,
            explanation = explanation,
            limitations = limitations
        )
    }
}
