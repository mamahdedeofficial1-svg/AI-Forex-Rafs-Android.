
class MultiIndicatorAnalyzer:

    def analyze(self, analyses):

        if not isinstance(analyses, list):
            analyses = []

        bullish = []
        bearish = []
        mixed = []
        unknown = []

        for item in analyses:

            if not isinstance(item, dict):
                continue

            indicator = item.get("indicator", "UNKNOWN")
            impact = item.get("usd_impact", "UNKNOWN")

            if impact in [
                "POTENTIALLY_BULLISH",
                "POTENTIALLY_USD_BULLISH"
            ]:
                bullish.append(indicator)

            elif impact in [
                "POTENTIALLY_BEARISH",
                "POTENTIALLY_USD_BEARISH"
            ]:
                bearish.append(indicator)

            elif impact in [
                "MIXED",
                "CONFLICTING"
            ]:
                mixed.append(indicator)

            else:
                unknown.append(indicator)

        bullish_count = len(bullish)
        bearish_count = len(bearish)

        if bullish_count > bearish_count:
            overall = "POTENTIALLY_USD_BULLISH"

        elif bearish_count > bullish_count:
            overall = "POTENTIALLY_USD_BEARISH"

        elif bullish_count > 0 and bearish_count > 0:
            overall = "CONFLICTING_SIGNALS"

        else:
            overall = "INSUFFICIENT_DATA"

        if overall == "POTENTIALLY_USD_BULLISH":
            gold = "POTENTIALLY_GOLD_BEARISH"

        elif overall == "POTENTIALLY_USD_BEARISH":
            gold = "POTENTIALLY_GOLD_BULLISH"

        else:
            gold = "UNCERTAIN"

        return {
            "overall_usd": overall,
            "potential_gold_impact": gold,
            "bullish_factors": bullish,
            "bearish_factors": bearish,
            "mixed_factors": mixed,
            "unknown_factors": unknown,
            "indicator_count": len(analyses),
            "analyzed_count": (
                bullish_count +
                bearish_count +
                len(mixed)
            ),
            "explanation": (
                "Analisis menggabungkan hasil beberapa "
                "indikator ekonomi. Setiap indikator "
                "dibandingkan dengan forecast dan "
                "diinterpretasikan secara terpisah. "
                "Hasil merupakan hipotesis edukatif, "
                "bukan kepastian pergerakan pasar. "
                "Perhatikan revisi data, ekspektasi "
                "pasar, kebijakan Federal Reserve, "
                "dan respons harga."
            ),
            "status": "educational"
        }
