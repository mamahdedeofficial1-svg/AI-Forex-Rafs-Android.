
package com.forexintelligence.ai.engine

import kotlin.math.abs

enum class MarketTrend {
    BULLISH,
    BEARISH,
    SIDEWAYS,
    INSUFFICIENT_DATA
}

data class TechnicalResult(
    val ema20: Double?,
    val ema50: Double?,
    val rsi14: Double?,
    val macd: Double?,
    val signal: Double?,
    val histogram: Double?,
    val trend: MarketTrend,
    val confidence: Int,
    val explanation: List<String>
)

object TechnicalAnalyzer {

    fun analyze(closes: List<Double>): TechnicalResult {

        if (closes.size < 60) {
            return TechnicalResult(
                null, null, null, null, null, null,
                MarketTrend.INSUFFICIENT_DATA,
                0,
                listOf("Data belum cukup untuk analisis.")
            )
        }

        val ema20 = calculateEma(closes, 20)
        val ema50 = calculateEma(closes, 50)
        val rsi = calculateRsi(closes, 14)

        val ema12Series = emaSeries(closes, 12)
        val ema26Series = emaSeries(closes, 26)

        val macdSeries = ema12Series.zip(ema26Series) {
            fast, slow -> fast - slow
        }

        val macd = macdSeries.last()
        val signal = calculateEma(macdSeries, 9)
        val histogram = macd - signal

        val explanations = mutableListOf<String>()
        var bullishPoints = 0
        var bearishPoints = 0

        if (ema20 > ema50) {
            bullishPoints++
            explanations.add("EMA20 berada di atas EMA50.")
        } else {
            bearishPoints++
            explanations.add("EMA20 berada di bawah EMA50.")
        }

        if (closes.last() > ema20) {
            bullishPoints++
            explanations.add("Harga berada di atas EMA20.")
        } else {
            bearishPoints++
            explanations.add("Harga berada di bawah EMA20.")
        }

        if (rsi > 55) {
            bullishPoints++
            explanations.add("RSI menunjukkan momentum positif.")
        } else if (rsi < 45) {
            bearishPoints++
            explanations.add("RSI menunjukkan momentum negatif.")
        } else {
            explanations.add("RSI berada di area tengah.")
        }

        if (histogram > 0) {
            bullishPoints++
            explanations.add("MACD histogram positif.")
        } else {
            bearishPoints++
            explanations.add("MACD histogram negatif.")
        }

        val total = bullishPoints + bearishPoints

        val trend = when {
            bullishPoints >= 3 -> MarketTrend.BULLISH
            bearishPoints >= 3 -> MarketTrend.BEARISH
            else -> MarketTrend.SIDEWAYS
        }

        val confidence = (
            maxOf(bullishPoints, bearishPoints) * 25
        ).coerceIn(0, 100)

        return TechnicalResult(
            ema20,
            ema50,
            rsi,
            macd,
            signal,
            histogram,
            trend,
            confidence,
            explanations
        )
    }

    private fun calculateEma(
        values: List<Double>,
        period: Int
    ): Double {
        return emaSeries(values, period).last()
    }

    private fun emaSeries(
        values: List<Double>,
        period: Int
    ): List<Double> {

        val multiplier = 2.0 / (period + 1)
        val result = mutableListOf<Double>()

        var ema = values.take(period).average()
        result.add(ema)

        for (i in period until values.size) {
            ema = (
                values[i] - ema
            ) * multiplier + ema

            result.add(ema)
        }

        return result
    }

    private fun calculateRsi(
        values: List<Double>,
        period: Int
    ): Double {

        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val change = values[i] - values[i - 1]

            if (change > 0) gains += change
            else losses += abs(change)
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in period + 1 until values.size) {
            val change = values[i] - values[i - 1]

            avgGain = (
                avgGain * (period - 1) +
                maxOf(change, 0.0)
            ) / period

            avgLoss = (
                avgLoss * (period - 1) +
                maxOf(-change, 0.0)
            ) / period
        }

        if (avgLoss == 0.0) return 100.0

        val rs = avgGain / avgLoss

        return 100.0 - (100.0 / (1.0 + rs))
    }
}
