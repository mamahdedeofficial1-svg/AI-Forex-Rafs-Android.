
package com.forexintelligence.ai.intelligence

import com.forexintelligence.ai.model.NewsArticle
import com.forexintelligence.ai.model.NewsAnalysis
import com.forexintelligence.ai.model.NewsSentiment

object NewsIntelligenceEngine {

    private val positiveKeywords = listOf(
        "strong growth",
        "economic growth",
        "higher interest rates",
        "rate hike",
        "hawkish",
        "strong employment",
        "jobs increased",
        "inflation remains high",
        "higher inflation",
        "strong dollar",
        "higher yields"
    )

    private val negativeKeywords = listOf(
        "economic slowdown",
        "weak employment",
        "jobs declined",
        "rate cut",
        "dovish",
        "lower interest rates",
        "recession",
        "unemployment increased",
        "weak dollar",
        "lower yields",
        "inflation decreased"
    )

    fun analyze(article: NewsArticle): NewsAnalysis {

        val text = (
            article.title + " " +
            article.summary
        ).lowercase()

        val positiveMatches = positiveKeywords.filter {
            text.contains(it)
        }

        val negativeMatches = negativeKeywords.filter {
            text.contains(it)
        }

        val score = (
            positiveMatches.size - negativeMatches.size
        ).coerceIn(-100, 100)

        val sentiment = when {
            positiveMatches.isNotEmpty() &&
                negativeMatches.isNotEmpty() ->
                NewsSentiment.UNCERTAIN

            score > 0 -> NewsSentiment.POSITIVE
            score < 0 -> NewsSentiment.NEGATIVE
            else -> NewsSentiment.NEUTRAL
        }

        val explanation = when (sentiment) {

            NewsSentiment.POSITIVE ->
                "Terdapat kata atau informasi yang secara umum mendukung USD. Perlu diperiksa terhadap konteks dan data aktual."

            NewsSentiment.NEGATIVE ->
                "Terdapat kata atau informasi yang secara umum menekan USD. Perlu diperiksa terhadap konteks dan data aktual."

            NewsSentiment.NEUTRAL ->
                "Belum ditemukan indikasi sentimen USD yang jelas."

            NewsSentiment.UNCERTAIN ->
                "Berita mengandung indikasi positif dan negatif sekaligus. Kesimpulan belum dapat ditentukan."
        }

        return NewsAnalysis(
            article = article,
            sentiment = sentiment,
            score = score,
            explanation = explanation,
            keywords = positiveMatches + negativeMatches
        )
    }
}
