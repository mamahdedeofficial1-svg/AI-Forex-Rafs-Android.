
package com.forexintelligence.ai.model

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

enum class Timeframe(val apiValue: String) {
    M15("15min"),
    H1("1h"),
    H4("4h"),
    D1("1day")
}

data class MarketData(
    val symbol: String,
    val timeframe: Timeframe,
    val candles: List<Candle>,
    val source: String,
    val lastUpdated: Long
)
