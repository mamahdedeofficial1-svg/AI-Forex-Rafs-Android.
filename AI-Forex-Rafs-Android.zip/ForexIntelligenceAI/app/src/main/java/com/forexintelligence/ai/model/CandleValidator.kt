
package com.forexintelligence.ai.model

data class DataValidation(
    val isValid: Boolean,
    val errors: List<String>
)

object CandleValidator {

    fun validate(candles: List<Candle>): DataValidation {

        val errors = mutableListOf<String>()

        if (candles.size < 60) {
            errors.add("Jumlah candle kurang dari 60.")
        }

        if (candles.isEmpty()) {
            errors.add("Data candle kosong.")
        }

        candles.forEachIndexed { index, candle ->

            if (
                candle.open <= 0 ||
                candle.high <= 0 ||
                candle.low <= 0 ||
                candle.close <= 0
            ) {
                errors.add("Harga tidak valid pada candle $index.")
            }

            if (candle.high < candle.low) {
                errors.add("High lebih kecil dari Low pada candle $index.")
            }

            if (
                candle.high < maxOf(candle.open, candle.close)
            ) {
                errors.add("High tidak mencakup Open/Close pada candle $index.")
            }

            if (
                candle.low > minOf(candle.open, candle.close)
            ) {
                errors.add("Low tidak mencakup Open/Close pada candle $index.")
            }

            if (candle.volume < 0) {
                errors.add("Volume negatif pada candle $index.")
            }

            if (
                index > 0 &&
                candle.timestamp <= candles[index - 1].timestamp
            ) {
                errors.add("Urutan timestamp tidak meningkat.")
            }
        }

        return DataValidation(
            isValid = errors.isEmpty(),
            errors = errors.distinct()
        )
    }
}
