
package com.forexintelligence.ai.model

enum class NewsImpact {
    LOW,
    MEDIUM,
    HIGH,
    UNKNOWN
}

data class EconomicEvent(
    val id: String,
    val eventName: String,
    val currency: String,
    val country: String,
    val impact: NewsImpact,
    val scheduledTime: Long,
    val actual: String?,
    val forecast: String?,
    val previous: String?,
    val source: String
)
