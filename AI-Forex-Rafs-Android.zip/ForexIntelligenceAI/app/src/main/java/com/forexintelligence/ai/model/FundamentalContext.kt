
package com.forexintelligence.ai.model

data class FundamentalContext(
    val analyses: List<FundamentalAnalysis>,
    val overallImpact: FundamentalImpact,
    val bullishFactors: List<String>,
    val bearishFactors: List<String>,
    val neutralFactors: List<String>,
    val summary: String
)
