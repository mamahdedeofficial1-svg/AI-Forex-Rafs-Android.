
package com.forexintelligence.ai.model

enum class EconomicIndicator {
    NFP,
    CPI,
    CORE_CPI,
    PPI,
    GDP,
    PCE,
    CORE_PCE,
    UNEMPLOYMENT_RATE,
    FED_INTEREST_RATE,
    FOMC,
    OTHER
}

enum class FundamentalImpact {
    USD_BULLISH,
    USD_BEARISH,
    NEUTRAL,
    MIXED,
    UNKNOWN
}

data class EconomicRelease(
    val indicator: EconomicIndicator,
    val actual: Double?,
    val forecast: Double?,
    val previous: Double?,
    val unit: String,
    val releaseTime: Long
)

data class FundamentalAnalysis(
    val indicator: EconomicIndicator,
    val impact: FundamentalImpact,
    val explanation: String,
    val actualVsForecast: String,
    val dataComplete: Boolean
)
