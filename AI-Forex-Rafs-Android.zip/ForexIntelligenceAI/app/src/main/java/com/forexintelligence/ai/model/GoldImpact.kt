
package com.forexintelligence.ai.model

enum class GoldDirection {
    POTENTIAL_UP,
    POTENTIAL_DOWN,
    MIXED,
    UNCERTAIN
}

data class GoldImpactAnalysis(
    val direction: GoldDirection,
    val score: Int,
    val supportingFactors: List<String>,
    val opposingFactors: List<String>,
    val explanation: String,
    val limitations: List<String>
)
