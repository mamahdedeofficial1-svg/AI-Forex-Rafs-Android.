
package com.forexintelligence.ai.model

data class MarketContext(
    val symbol: String,
    val timeframe: String,
    val fundamentalSummary: String,
    val technicalSummary: String,
    val newsSummary: String,
    val goldImpactSummary: String,
    val lastUpdated: Long
)
