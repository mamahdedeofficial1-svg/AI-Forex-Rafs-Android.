
package com.forexintelligence.ai.model

enum class NewsSentiment {
    POSITIVE,
    NEGATIVE,
    NEUTRAL,
    UNCERTAIN
}

data class NewsArticle(
    val id: String,
    val title: String,
    val summary: String,
    val source: String,
    val url: String,
    val publishedAt: Long,
    val currency: String
)

data class NewsAnalysis(
    val article: NewsArticle,
    val sentiment: NewsSentiment,
    val score: Int,
    val explanation: String,
    val keywords: List<String>
)
