
package com.forexintelligence.ai.network

import com.forexintelligence.ai.config.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

object ApiClient {

    // Alamat backend AI Forex Rafs.
    // Untuk sekarang belum ada server yang terhubung.
    private val BASE_URL =
    AppConfig.BASE_URL

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun get(
        endpoint: String
    ): Result<String> = withContext(Dispatchers.IO) {

        try {

            require(
                endpoint.startsWith("/") &&
                !endpoint.startsWith("//") &&
                !endpoint.contains("..")
            ) {
                "Endpoint tidak valid."
            }

            val request = Request.Builder()
                .url(BASE_URL + endpoint)
                .get()
                .build()

            client.newCall(request).execute().use { response ->

                if (!response.isSuccessful) {
                    throw IOException(
                        "Server error: ${response.code}"
                    )
                }

                val body = response.body?.string()
                    ?: throw IOException("Respons kosong.")

                Result.success(body)
            }

        } catch (exception: Exception) {

            Result.failure(exception)
        }
    }
}
