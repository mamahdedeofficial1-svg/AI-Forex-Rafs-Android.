
package com.forexintelligence.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.forexintelligence.ai.data.AIAnalystRepository
import com.forexintelligence.ai.model.ChatMessage
import com.forexintelligence.ai.model.ChatRole
import com.forexintelligence.ai.model.MarketContext
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun AIAnalystScreen() {

    val repository = remember {
        AIAnalystRepository()
    }

    val scope = rememberCoroutineScope()

    var question by remember {
        mutableStateOf("")
    }

    var isLoading by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf<String?>(null)
    }

    val messages = remember {
        mutableStateListOf<ChatMessage>()
    }

    val marketContext = remember {
        MarketContext(
            symbol = "XAU/USD",
            timeframe = "H1",
            fundamentalSummary = "Data fundamental belum terhubung.",
            technicalSummary = "Data teknikal belum terhubung.",
            newsSummary = "Berita terbaru belum terhubung.",
            goldImpactSummary = "Analisis dampak emas belum tersedia.",
            lastUpdated = System.currentTimeMillis()
        )
    }

    fun sendMessage() {

        val userQuestion = question.trim()

        if (userQuestion.isBlank() || isLoading) {
            return
        }

        val userMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            role = ChatRole.USER,
            content = userQuestion
        )

        messages.add(userMessage)
        question = ""
        errorMessage = null
        isLoading = true

        scope.launch {

            val history = messages.toList()

            val result = repository.ask(
                question = userQuestion,
                context = marketContext,
                history = history
            )

            result.onSuccess { answer ->

                messages.add(
                    ChatMessage(
                        id = UUID.randomUUID().toString(),
                        role = ChatRole.ASSISTANT,
                        content = answer
                    )
                )

            }.onFailure { error ->

                errorMessage = error.message
                    ?: "Terjadi kesalahan saat menghubungi AI."

            }

            isLoading = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B1220))
            .padding(16.dp)
    ) {

        Text(
            text = "AI MARKET ANALYST",
            color = Color.White,
            fontSize = 21.sp
        )

        Text(
            text = "Konsultasi analisis pasar XAU/USD",
            color = Color.LightGray,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            if (messages.isEmpty()) {
                item {
                    WelcomeMessage()
                }
            }

            items(
                items = messages,
                key = { it.id }
            ) { message ->

                ChatBubble(message)
            }

            if (isLoading) {
                item {
                    Text(
                        text = "AI sedang memproses pertanyaan...",
                        color = Color(0xFF60A5FA),
                        fontSize = 13.sp
                    )
                }
            }
        }

        errorMessage?.let { error ->

            Text(
                text = error,
                color = Color(0xFFF87171),
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(6.dp))
        }

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {

            OutlinedTextField(
                value = question,
                onValueChange = {
                    question = it
                },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text("Tanyakan sesuatu...")
                },
                maxLines = 4,
                enabled = !isLoading,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color(0xFF60A5FA),
                    unfocusedBorderColor = Color.Gray,
                    focusedPlaceholderColor = Color.Gray,
                    unfocusedPlaceholderColor = Color.Gray
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = { sendMessage() },
                enabled = question.isNotBlank() && !isLoading
            ) {
                Text("Kirim")
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Analisis bersifat edukatif dan dapat mengandung ketidakpastian.",
            color = Color.Gray,
            fontSize = 10.sp
        )
    }
}

@Composable
private fun WelcomeMessage() {

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 35.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "AI Forex Rafs",
            color = Color.White,
            fontSize = 25.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Apa yang ingin kamu pelajari tentang pasar hari ini?",
            color = Color.LightGray,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun ChatBubble(
    message: ChatMessage
) {

    val isUser = message.role == ChatRole.USER

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) {
            Arrangement.End
        } else {
            Arrangement.Start
        }
    ) {

        Surface(
            color = if (isUser) {
                Color(0xFF1D4ED8)
            } else {
                Color(0xFF1E293B)
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.widthIn(max = 300.dp)
        ) {

            Text(
                text = message.content,
                color = Color.White,
                modifier = Modifier.padding(12.dp),
                fontSize = 14.sp
            )
        }
    }
}
